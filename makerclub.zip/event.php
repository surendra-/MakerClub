<?php 

include('header.php');

?>
 
   <div class="section white">
	<div class="container">
		<div class="row ">
			 <h2>Join others at events around the country.</h2>
			 <a class="waves-effect waves-light btn-large" style="text-transform:normal"><i class="mdi-action-search left"></i>Find an event</a>
			  <a class="waves-effect waves-light btn-large"><i class="mdi-content-add left"></i>Add an event</a
		</div>
	</div>
 </div>
 <div class="row"> 
	<div class="container"><p class="right">Coming Soon...</p></div>
 </div>

  <?php

include("footer.php");

?>