<?php 

include('header.php');

?>
 <style>
	.bullet li{
		list-style-type:square;
		margin-left:20px;
	}
</style>
   <div class="section white">
	<div class="container">
		<div class="row ">
			<h3>Build your maker skills & earn badges!</h3><p>
			<ul class="bullet">
			<li>Browse our resources or participate in professional development.</li>
			<li>Join or host local events to collaborate with peers and teach learners.</li>
			<li>Show others how to make things and collect the Maker Skill Sharer badge. When you're ready, apply for the Maker Club Mentor Badge.</li></ul></p>
		</div>
	</div>
 </div>
 <div class="row"> 
	<div class="container"><p class="right">Coming Soon...</p></div>
 </div>

  <?php

include("footer.php");

?>