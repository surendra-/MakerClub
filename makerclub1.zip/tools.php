
<?php 

include('header.php');

?>
<style>
	.tools li{
		list-style-type:square;
	}
</style>
<div class="section">
<div class="container">
	<div class="row">
	<h3>Tools</h3>
	<ul class="tools">
		<li>Electronic Tools</li>
		<li>3D Printer</li>
		<li>Woodworking Tools</li>
		<li>Hand Power Tools</li>
		<li>Support & Safety Tools</li>
		<li>Mechanical Machines</li>
		<li>Design & Prototyping Tools</li>
	</ul>
	</div>
</div>
</div>

<?php

include("footer.php");

?>